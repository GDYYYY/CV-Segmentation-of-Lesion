import os
import cv2
import matplotlib.pyplot as plt
import numpy as np
import math

gray_level = 16  # 灰度级数
window_w = 7
window_h = 7


def getMaxGrayLevel(img):
    max_gray_level = 0
    height, width = img.shape[:2]
    for y in range(height):
        for x in range(width):
            if img[y][x] > max_gray_level:
                max_gray_level = img[y][x]
    return max_gray_level + 1


def grayDown(img, max_gray_level):
    height, width = img.shape[:2]
    # 减小灰度级数
    if max_gray_level > gray_level:
        for j in range(height):
            for i in range(width):
                img[j][i] = img[j][i] * gray_level / max_gray_level
    return img


def getGLCM(img, dx, dy):
    ans = np.zeros((gray_level, gray_level), dtype=np.uint8)
    height, width = img.shape[:2]

    # 计算共生矩阵
    for j in range(height - dy):
        for i in range(width - dx):
            x = img[j][i]
            y = img[j + dy][i + dx]
            # print(j, i, x, y)
            ans[x][y] += 1
    # print('GLCM')
    # print(ans)

    # 归一化
    # sum = (height - dy) * (width - dx)
    # for i in range(gray_level):
    #     for j in range(gray_level):
    #         ans[i][j] = float(ans[i][j] / sum)

    return ans


def feature(m):
    # print('m')
    # print(m)
    contrast = 0.0  # 对比度
    energy = 0.0  # 能量
    entropy = 0.0  # 熵
    homogeneity = 0.0  # 一致性
    for i in range(gray_level):
        for j in range(gray_level):
            contrast += (i - j) * (i - j) * m[i][j]
            energy += int(m[i][j] * m[i][j])
            homogeneity += m[i][j] / (1 + (i - j) * (i - j))
            if m[i][j] > 0.0:
                entropy += m[i][j] * math.log(m[i][j])
    # print(energy)
    return contrast, energy, -entropy, homogeneity


def feature2gray(m, maxValue):
    print(maxValue)
    # if maxValue <= 255:
    #     return m
    height, width = m.shape[:2]
    for j in range(height):
        for i in range(width):
            m[j][i] = m[j][i] * 255 / maxValue
            # if m[j][i] != 0:
            #     m[j][i] = 200
    return m


def focalSegment():
    reticular_path = "../reticular"
    standard_path = "../pretreat/honeycombing"
    parenchyma_path = "../honeycombing_preprocess"

    for root, dirs, files in os.walk(standard_path):
        for filename in files:
            # 读取肺实质图像
            path = os.path.join(root, filename)
            img = cv2.imread(path)
            gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
            height, width = gray.shape[:2]
            max_gray = getMaxGrayLevel(gray)
            gray = grayDown(gray, max_gray)  # 减少灰度级数

            # 记录各特征值
            cont = np.zeros(gray.shape[:2], dtype=np.uint8)
            nrg = np.zeros(gray.shape[:2], dtype=np.uint8)
            ntp = np.zeros(gray.shape[:2], dtype=np.uint8)
            hom = np.zeros(gray.shape[:2], dtype=np.uint8)

            # 按小区域计算GLCM
            hw = int(window_w / 2)
            hh = int(window_h / 2)
            maxCont, maxNrg, maxNtp, maxHom = 0, 0, 0, 0
            for i in range(window_h, height - window_h):
                for j in range(window_w, width - window_w):
                    if gray[i][j] != 0:  # 提高计算效率
                        window = gray[i - hh:i + hh + 1, j - hw:j + hw + 1]
                        # print(window)
                        glcm = getGLCM(window, 1, 0)
                        # print(glcm)
                        cont[i][j], nrg[i][j], ntp[i][j], hom[i][j] = feature(glcm)
                        # print(cont[i][j])
                        maxCont = max(cont[i][j], maxCont)
                        maxNrg = max(nrg[i][j], maxNrg)
                        maxNtp = max(ntp[i][j], maxNtp)
                        maxHom = max(hom[i][j], maxHom)
            # print(cont)
            # contImg = feature2gray(cont, maxCont)
            # nrgImg = feature2gray(nrg, maxNrg)
            # ntpImg = feature2gray(ntp, maxNtp)
            homImg = feature2gray(hom, maxHom)
            # plt.imshow(contImg)
            # plt.show()

            # glcm_0 = getGLCM(gray, 1, 0)
            # # print(glcm_0)
            # contrast, energy, entropy, homogeneity = feature(glcm_0)
            # print(contrast, energy, entropy, homogeneity)

            # 输出最终病灶结果
            # cv2.imwrite(r"../pretreat/contrast/" + filename, contImg)
            # cv2.imwrite(r"../pretreat/energy/" + filename, nrgImg)
            # cv2.imwrite(r"../pretreat/entropy/" + filename, ntpImg)
            cv2.imwrite(r"../pretreat/homogeneity/" + filename, homImg)


if __name__ == '__main__':
    focalSegment()
